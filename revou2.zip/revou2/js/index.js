document.addEventListener('DOMContentLoaded', function() {
    const calculateLBtn = document.getElementById('calculateLBtn');
    calculateLBtn.addEventListener('click', function() {
        const alas = parseFloat(document.getElementById('alas').value);
        const tinggi = parseFloat(document.getElementById('tinggi').value);

        if (!isNaN(alas) && !isNaN(tinggi)) {
            const area = 0.5 * alas * tinggi;
            const resultLuas = `Hasil Luas Segitiga adalah ${area.toFixed(2)}`;
            document.getElementById('resultLuas').textContent = resultLuas;
        } else {
            document.getElementById('resultLuas').textContent = 'Masukkan angka valid untuk alas dan tinggi!';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const calculateKBtn = document.getElementById('calculateKBtn');
    calculateKBtn.addEventListener('click', function() {
        const sideA = parseFloat(document.getElementById('sideA').value);
        const sideB = parseFloat(document.getElementById('sideB').value);
        const sideC = parseFloat(document.getElementById('sideC').value);

        if (!isNaN(sideA) && !isNaN(sideB) && !isNaN(sideC)) {
            const perimeter = sideA + sideB + sideC;
            const resultKeliling = `Hasil Keliling Segitiga adalah ${perimeter.toFixed(2)}`;
            document.getElementById('resultKeliling').textContent = resultKeliling;
        } else {
            document.getElementById('resultKeliling').textContent = 'Masukkan angka valid untuk semua sisi!';
        }
    });
});

